<?php 
// ACF Color Swatches
// https://wordpress.org/plugins/acf-color-swatches/
// https://github.com/nickforddesign/acf-swatch

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

include( ACFTC_PLUGIN_DIR_PATH . 'render/radio.php' );
